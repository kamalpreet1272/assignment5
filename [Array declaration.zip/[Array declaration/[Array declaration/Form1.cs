﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Array_declaration
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] number = new int[5];
            number[0] = int.Parse (textBox1.Text);
            number[1] = int.Parse(textBox2.Text);
            number[2] = int.Parse(textBox3.Text);
            number[3] = int.Parse(textBox4.Text);
            number[4] = int.Parse(textBox5.Text);

            for(int i=0; i<number.Length; i++)
            {
                label2.Text = label2.Text + " "+number[i].ToString();
            }
            int sum = 0;
            for(int i=0; i<number.Length; i++)
            {
                sum += number[i];
            }
            label4.Text = sum.ToString();
        }
        
    }
}
